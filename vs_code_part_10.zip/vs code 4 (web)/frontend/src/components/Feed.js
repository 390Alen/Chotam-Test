import React from 'react';

const Feed = () => {
  const feedItems = [
    { id: 1, user: 'Alen', action: 'completed a test on "History of Kazakhstan"', timestamp: '2 hours ago' },
    { id: 2, user: 'Aruzhan', action: 'created a new study plan for "IELTS"', timestamp: '5 hours ago' },
    { id: 3, user: 'Timur', action: 'earned the "Quick Learner" badge', timestamp: '1 day ago' }
  ];

  return (
    <div>
      <h2>Лента активности</h2>
      <div className="feed-list">
        {feedItems.map(item => (
          <div key={item.id} className="feed-item">
            <p><strong>{item.user}</strong> {item.action}</p>
            <span className="timestamp">{item.timestamp}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Feed;