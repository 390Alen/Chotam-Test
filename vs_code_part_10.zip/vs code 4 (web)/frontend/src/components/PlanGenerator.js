import React, { useState } from 'react';

const PlanGenerator = () => {
  const [subject, setSubject] = useState('');
  const [goal, setGoal] = useState('');
  const [deadline, setDeadline] = useState('');
  const [plan, setPlan] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setPlan('Генерируем план...');
    try {
      const response = await fetch('http://localhost:5002/api/generate-plan', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ subject, goal, deadline }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      setPlan(data.plan);
    } catch (error) {
      console.error('Error generating plan:', error);
      setPlan('Не удалось сгенерировать план. Попробуйте еще раз.');
    }
  };

  return (
    <div>
      <h2>Генератор Учебных Планов</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Предмет" required />
        <input type="text" value={goal} onChange={(e) => setGoal(e.target.value)} placeholder="Цель" required />
        <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} required />
        <button type="submit">Сгенерировать</button>
      </form>
      {plan && (
        <div className="plan-output">
          <h3>Ваш учебный план:</h3>
          <pre>{plan}</pre>
        </div>
      )}
    </div>
  );
};

export default PlanGenerator;