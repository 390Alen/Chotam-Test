import React, { useState } from 'react';

const Summarizer = () => {
  const [file, setFile] = useState(null);
  const [summary, setSummary] = useState('');

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (file) {
      // Логика отправки файла и получения конспекта
      const generatedSummary = `Это краткий конспект вашего файла: ${file.name}`;
      setSummary(generatedSummary);
    }
  };

  return (
    <div>
      <h2>AI-Конспектчик</h2>
      <form onSubmit={handleSubmit}>
        <input type="file" onChange={handleFileChange} accept=".pdf,.jpg,.jpeg,.png" required />
        <button type="submit">Сделать конспект</button>
      </form>
      {summary && (
        <div className="summary-output">
          <h3>Ваш конспект:</h3>
          <p>{summary}</p>
        </div>
      )}
    </div>
  );
};

export default Summarizer;