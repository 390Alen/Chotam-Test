import React, { useState, useEffect } from 'react';

const MotivationCoach = () => {
  const [quote, setQuote] = useState('');

  useEffect(() => {
    // Здесь будет логика получения цитаты дня
    const motivationalQuotes = [
      "The only way to do great work is to love what you do. - Steve Jobs",
      "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
      "Believe you can and you're halfway there. - Theodore Roosevelt"
    ];
    const randomQuote = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)];
    setQuote(randomQuote);
  }, []);

  return (
    <div>
      <h2>Мотивационный Коуч</h2>
      <div className="quote-of-the-day">
        <h3>Цитата дня:</h3>
        <p>{quote}</p>
      </div>
    </div>
  );
};

export default MotivationCoach;