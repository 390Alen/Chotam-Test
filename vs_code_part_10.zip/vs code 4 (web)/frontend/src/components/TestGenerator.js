import React, { useState } from 'react';

const TestGenerator = () => {
  const [topic, setTopic] = useState('');
  const [items, setItems] = useState([]);
  const [type, setType] = useState('test'); // 'test' or 'flashcards'

  const handleSubmit = async (e) => {
    e.preventDefault();
    setItems([]);
    try {
      const response = await fetch('http://localhost:5002/api/generate-test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ topic, type }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok');
      }

      const data = await response.json();
      try {
        // The AI response might be a string that needs to be cleaned up before parsing.
        const jsonString = data.items.replace(/```json\n|```/g, '');
        const parsedItems = JSON.parse(jsonString);
        setItems(parsedItems);
      } catch (e) {
        console.error("Failed to parse AI response:", e);
        // If parsing fails, just display the raw text.
        setItems([{ question: "Raw AI Response", answer: data.items }]);
      }
    } catch (error) {
      console.error('Error generating test:', error);
    }
  };

  return (
    <div>
      <h2>Генератор тестов и флеш-карт</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Тема" required />
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value="test">Тест</option>
          <option value="flashcards">Флеш-карты</option>
        </select>
        <button type="submit">Сгенерировать</button>
      </form>
      <div className="generated-items">
        {type === 'test' && items.map((item, index) => (
          <div key={index} className="test-item">
            <p><strong>Вопрос:</strong> {item.question}</p>
            <p><strong>Ответ:</strong> {item.answer}</p>
          </div>
        ))}
        {type === 'flashcards' && items.map((item, index) => (
          <div key={index} className="flashcard">
            <div className="card-front">{item.term}</div>
            <div className="card-back">{item.definition}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TestGenerator;