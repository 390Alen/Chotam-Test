import React from 'react';

const Templates = () => {
  const templates = [
    { id: 1, name: 'Подготовка к ЕНТ', description: 'Шаблон плана для подготовки к Единому Национальному Тестированию.' },
    { id: 2, name: 'Подготовка к HSK 4', description: 'Шаблон плана для подготовки к HSK 4.' },
    { id: 3, name: 'Подготовка к IELTS', description: 'Шаблон плана для подготовки к IELTS.' }
  ];

  return (
    <div>
      <h2>Шаблоны</h2>
      <div className="template-list">
        {templates.map(template => (
          <div key={template.id} className="template-item">
            <h3>{template.name}</h3>
            <p>{template.description}</p>
            <button>Использовать шаблон</button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Templates;