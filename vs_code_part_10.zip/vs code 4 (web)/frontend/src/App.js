import React, { useState } from 'react';
import './App.css';
import TutorChat from './components/TutorChat';
import PlanGenerator from './components/PlanGenerator';
import Summarizer from './components/Summarizer';
import MotivationCoach from './components/MotivationCoach';
import TestGenerator from './components/TestGenerator';
import Feed from './components/Feed';
import Templates from './components/Templates';
import './components/TutorChat.css';
import './components/PlanGenerator.css';
import './components/Summarizer.css';
import './components/MotivationCoach.css';
import './components/TestGenerator.css';
import './components/Feed.css';
import './components/Templates.css';

function App() {
  const [activeTab, setActiveTab] = useState('tutor');
  console.log('Active tab:', activeTab);

  return (
    <div className="App">
      <header className="App-header">
        <h1>Chotam test</h1>
        <nav>
          <button onClick={() => setActiveTab('tutor')}>AI-Репетитор</button>
          <button onClick={() => setActiveTab('planner')}>Генератор планов</button>
          <button onClick={() => setActiveTab('summarizer')}>AI-Конспектчик</button>
          <button onClick={() => setActiveTab('coach')}>Мотивационный Коуч</button>
          <button onClick={() => setActiveTab('tester')}>Генератор тестов</button>
          <button onClick={() => setActiveTab('feed')}>Лента</button>
          <button onClick={() => setActiveTab('templates')}>Шаблоны</button>
        </nav>
      </header>
      <main>
        {activeTab === 'tutor' && <TutorChat />}
        {activeTab === 'planner' && <PlanGenerator />}
        {activeTab === 'summarizer' && <Summarizer />}
        {activeTab === 'coach' && <MotivationCoach />}
        {activeTab === 'tester' && <TestGenerator />}
        {activeTab === 'feed' && <Feed />}
        {activeTab === 'templates' && <Templates />}
      </main>
    </div>
  );
}

export default App;